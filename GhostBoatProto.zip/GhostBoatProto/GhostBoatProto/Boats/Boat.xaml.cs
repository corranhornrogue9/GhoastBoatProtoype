﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace GhostBoatProto.Boats
{
    /// <summary>
    /// Interaction logic for Boat.xaml
    /// </summary>
    public partial class Boat : UserControl
    {
        private float rebase;
    
       
        public Boat()
        {
            InitializeComponent();
            
        }

        private void FinishedButtomn_Click(object sender, RoutedEventArgs e)
        {
            EndedRace = true;
            Dispatcher.Invoke(() =>
            {
                FinishedButtomn.IsEnabled = false;

            });
        }

        public bool EndedRace
        {
            get;
            set;
        }

        public void StartRace(float rebase)
        {
            EndedRace = false;
            Dispatcher.Invoke(() =>
            {
                BoatName.IsReadOnly = true;
                IRC.IsReadOnly = true;
                FinishedButtomn.IsEnabled = true;
                this.rebase = rebase;
            });
        }

        public void UpdateTime(TimeSpan time)
        {
            if(!EndedRace)
            {
                Dispatcher.Invoke(() =>
                {
                    CorrectedTimeBar.Value = (time.Ticks * (rebase * GetIRC())) / GetEstimatedMinutesLeft(10).Ticks;
                    CorrectedTime.Text = TimeSpan.FromTicks((long)(time.Ticks * GetIRC())).ToString();
                });
            }
        }

        public float GetIRC()
        {
            var retVal = 1.0f;
            try
            {
                retVal = (float)Convert.ToDouble(IRC.Text);
            }
            catch(Exception e)
            {

            }

            return retVal;
        }

        private TimeSpan GetEstimatedMinutesLeft(int minutes)
        {
            int retVal = 60;
          

            return TimeSpan.FromMinutes(retVal);
        }
    }
}
