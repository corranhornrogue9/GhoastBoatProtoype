﻿using GhostBoatProto.Boats;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace GhostBoatProto
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private ObservableCollection<Boat> boats;
        private DateTime startTime;
        public MainWindow()
        {
            InitializeComponent();
            boats = new ObservableCollection<Boat>();
            Boats.ItemsSource = boats;
        }

        private void Button_ClickAddBoat(object sender, RoutedEventArgs e)
        {
            boats.Add(new Boat());
        }

        private void Button_ClickStartRace(object sender, RoutedEventArgs e)
        {
            var slowestBoat = boats.OrderByDescending(b => b.GetIRC()).First().GetIRC();
            var rebase = 1f / slowestBoat;
            foreach(var baot in boats)
            {
                baot.StartRace(rebase);
            }
            startTime = DateTime.Now;
            Task.Run(() => BoatUpdate());

            Dispatcher.Invoke(() =>
            {
                StartRace.IsEnabled = false;
                AddBoat.IsEnabled = false;
            });
        }

        private async Task BoatUpdate()
        {
            var boatsFinihed = false;
            while(!boatsFinihed)
            {
                var currentTime = DateTime.Now - startTime;
                foreach (var baot in boats)
                {
                    baot.UpdateTime(currentTime);
                }

                if(!boats.Any(b => !b.EndedRace))
                {
                    boatsFinihed = true;
                    Dispatcher.Invoke(() =>
                    {
                        StartRace.IsEnabled = true;
                        AddBoat.IsEnabled = true;
                    });
                }

                Thread.Sleep(500);
            }
        }
    }
}
